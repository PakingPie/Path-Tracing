//
// Created by Göksu Güvendiren on 2019-05-14.
//

#include "Scene.hpp"


void Scene::buildBVH() {
    printf(" - Generating BVH...\n\n");
    this->bvh = new BVHAccel(objects, 1, BVHAccel::SplitMethod::NAIVE);
}

Intersection Scene::intersect(const Ray &ray) const
{
    return this->bvh->Intersect(ray);
}

void Scene::sampleLight(Intersection &pos, float &pdf) const
{
    float emit_area_sum = 0;
    for (uint32_t k = 0; k < objects.size(); ++k) {
        if (objects[k]->hasEmit()){
            emit_area_sum += objects[k]->getArea();
        }
    }
    float p = get_random_float() * emit_area_sum;
    emit_area_sum = 0;
    for (uint32_t k = 0; k < objects.size(); ++k) {
        if (objects[k]->hasEmit()){
            emit_area_sum += objects[k]->getArea();
            if (p <= emit_area_sum){
                objects[k]->Sample(pos, pdf);
                break;
            }
        }
    }
}

bool Scene::trace(
        const Ray &ray,
        const std::vector<Object*> &objects,
        float &tNear, uint32_t &index, Object **hitObject)
{
    *hitObject = nullptr;
    for (uint32_t k = 0; k < objects.size(); ++k) {
        float tNearK = kInfinity;
        uint32_t indexK;
        Vector2f uvK;
        if (objects[k]->intersect(ray, tNearK, indexK) && tNearK < tNear) {
            *hitObject = objects[k];
            tNear = tNearK;
            index = indexK;
        }
    }


    return (*hitObject != nullptr);
}



// Implementation of Path Tracing
Vector3f Scene::castRay(const Ray &ray, int depth) const
{
    // TO DO Implement Path Tracing Algorithm here
    Intersection p_inter = intersect(ray);

    if(!p_inter.happened)
        return Vector3f();
    if(p_inter.m->hasEmission())
        return p_inter.m->getEmission();

    Vector3f l_dir = 0;
    Vector3f l_indir = 0;

    Vector3f p = p_inter.coords;
    Vector3f N = p_inter.normal.normalized();

    switch (p_inter.m->m_type)
    {
        case DIFFUSE:
        {
            MaterialType temp_m = DIFFUSE;
            Intersection x_inter;
            float pdf_light = 0.0f;

            // Get a ray 
            sampleLight(x_inter, pdf_light);

            Vector3f x = x_inter.coords;
            Vector3f NN = x_inter.normal.normalized();
            Vector3f emit = x_inter.emit;

            float ws_distance = (x - p).norm();
            Vector3f ws = (x - p).normalized();
            // Shoot a ray from p to x
            Intersection ws_p_to_x_intersection = intersect(Ray(p, ws));

            if(ws_p_to_x_intersection.distance - ws_distance > -0.0001f)
            {
                l_dir = emit * p_inter.m->eval(ray.direction, ws, N, temp_m) * dotProduct(ws, N) * dotProduct(-ws, NN) / std::pow(ws_distance, 2) / pdf_light;
            }

            if(get_random_float() > RussianRoulette)
                return l_dir;
            
            Vector3f wi = p_inter.m->sample(ray.direction, N, temp_m).normalized();
            Intersection wi_p_inter = intersect(Ray(p, wi));

            if(wi_p_inter.happened && !wi_p_inter.m->hasEmission() && p_inter.m->pdf(ray.direction, wi, N, temp_m) > EPSILON)
            {
                l_indir = castRay(Ray(p, wi), depth + 1) * p_inter.m->eval(ray.direction, wi, N, temp_m) * dotProduct(wi, N) / p_inter.m->pdf(ray.direction, wi, N, temp_m) / RussianRoulette;
            }
            break;
        }
        case MIRROR: // MIRROR
        {
            MaterialType temp_m = MIRROR;
            if(get_random_float() > RussianRoulette)
                return l_dir;
    
            Vector3f wi = p_inter.m->sample(ray.direction, N, temp_m).normalized();
            Intersection wi_p_inter = intersect(Ray(p, wi));

            if(wi_p_inter.happened && !wi_p_inter.m->hasEmission() && p_inter.m->pdf(ray.direction, wi, N, temp_m) > EPSILON)
            {
                l_indir = castRay(Ray(p, wi), depth + 1) * p_inter.m->eval(ray.direction, wi, N, temp_m) * dotProduct(wi, N) / p_inter.m->pdf(ray.direction, wi, N, temp_m) / RussianRoulette;
            }
            break;
        }
        case GLASS:
        {
            MaterialType temp_m;
            float random_number = get_random_float();
            
            if(random_number < p_inter.m->reflect_rate) // Reflection
            {
                temp_m = MIRROR;
            }
            else if(random_number >= p_inter.m->reflect_rate && random_number <= p_inter.m->refract_rate) // Refraction
            {
                temp_m = GLASS;
            }
            else //Diffuse
            {
                temp_m = DIFFUSE;
                Intersection x_inter;
                float pdf_light = 0.0f;

                // Get a ray 
                sampleLight(x_inter, pdf_light);

                Vector3f x = x_inter.coords;
                Vector3f NN = x_inter.normal.normalized();
                Vector3f emit = x_inter.emit;

                float ws_distance = (x - p).norm();
                Vector3f ws = (x - p).normalized();
                // Shoot a ray from p to x
                Intersection ws_p_to_x_intersection = intersect(Ray(p, ws));

                if(ws_p_to_x_intersection.distance - ws_distance > -0.0001f)
                {
                    l_dir = emit * p_inter.m->eval(ray.direction, ws, N, temp_m) * dotProduct(ws, N) * dotProduct(-ws, NN) / std::pow(ws_distance, 2) / pdf_light;
                }
            }

            if(get_random_float() > RussianRoulette)
                return l_dir;

            bool isInside = false;

            if(dotProduct(ray.direction, N) < 0)
            {
                N = -N;
            }

            Vector3f wi = p_inter.m->sample(ray.direction, N, temp_m).normalized();

            Intersection wi_p_inter = intersect(Ray(p, wi));
            
            if(wi_p_inter.happened && wi_p_inter.m->hasEmission() == false && p_inter.m->pdf(ray.direction, wi, N, temp_m) > EPSILON)
            {
                l_indir = castRay(Ray(p, wi), depth + 1).z * p_inter.m->eval(ray.direction, wi, N, temp_m)  * dotProduct(wi, N) / p_inter.m->pdf(ray.direction, wi, N, temp_m) / RussianRoulette;
            }
            if(temp_m == DIFFUSE)
            {
                l_dir = Vector3f(0.f, 0.f, l_dir.z);
                l_indir = Vector3f(0.f, 0.f, l_indir.z);
            }
            else if(temp_m == MIRROR)
            {
                l_dir = Vector3f(l_dir.x, 0.f, 0.f);
                l_indir = Vector3f(l_indir.x, 0.f, 0.f);
            }
            else
            {
                l_dir = Vector3f(0.f, l_dir.y, 0.f);
                l_indir = Vector3f(0.f, l_indir.y,0.f);
            }
            
            break;
        }                                                                    
    }
    

    return l_dir + l_indir;

}